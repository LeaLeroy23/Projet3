// Carousel

let sliderObject = new Slider('#home-slider');

